<?php

use App\Models\Tagging\Otsus\OpdTagOtsus;

class kode_modifikasi
{
    public function opd_tag_otsus()
    {
        $tags = OpdTagOtsus::get();

        foreach ($tags as $item) {
            $alias_dana = $item->sumberdana === 'Otsus 1%' ? 'bg' : ($item->sumberdana === 'Otsus 1,25%' ? 'sg' : 'dti');
            $item->alias_dana = $alias_dana;
            $item->save();
        }
    }

    public function rap_mod_kode_unik_opd_tag_otsus()
    {
        $tags = OpdTagOtsus::with('raps')->get();
        foreach ($tags as $itemTag) {
            foreach ($itemTag->raps as $itemRap) {
                $itemRap->kode_unik_opd_tag_otsus = $itemTag->kode_unik_opd_tag_otsus . '-' . $itemTag->alias_dana;
                $itemRap->save();
            }
            $itemTag->kode_unik_opd_tag_otsus = $itemTag->kode_unik_opd_tag_otsus . '-' . $itemTag->alias_dana;
            $itemTag->save();
        }
    }
}
