<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('opd_tag_otsuses', function (Blueprint $table) {
            $table->decimal('volume_usulan', 32, 2)->nullable()->after('volume');
            $table->enum('sumberdana_usulan', [
                "PAD",
                "DAU",
                "DBH",
                "DAK Fisik",
                "DAK Non Fisik",
                "Otsus 1%",
                "Otsus 1,25%",
                "DTI",
                "Tambahan DTI Migas",
                "Belanja KL",
                "Lainnya",
                "Tidak Ada",
            ])->index()->nullable()->after('sumberdana');
            $table->enum('alias_dana_usulan', ['bg', 'sg', 'dti'])->index()->nullable()->after('alias_dana');
        });

        // copy data lama ke kolom baru
        DB::table('opd_tag_otsuses')->update([
            'volume_usulan'      => DB::raw('volume'),
            'sumberdana_usulan'  => DB::raw('sumberdana'),
            'alias_dana_usulan'  => DB::raw('alias_dana'),
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('opd_tag_otsuses', function (Blueprint $table) {
            $table->dropColumn(['volume_usulan', 'sumberdana_usulan', 'alias_dana_usulan']);
        });
    }
};
