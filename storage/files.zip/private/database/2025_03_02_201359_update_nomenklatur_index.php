<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // $tables = [
        //     'a1_urusans',
        //     'a2_bidangs',
        //     'a3_programs',
        //     'a4_kegiatans',
        //     'a5_subkegiatans'
        // ];
        Schema::table('a1_urusans', function (Blueprint $table) {
            // Hapus constraint UNIQUE
            $table->dropUnique(['kode_urusan']);

            // Tambahkan INDEX biasa
            $table->index('kode_urusan');
        });
        Schema::table('a2_bidangs', function (Blueprint $table) {
            // Hapus constraint UNIQUE
            $table->dropUnique(['kode_bidang']);

            // Tambahkan INDEX biasa
            $table->index('kode_bidang');
        });
        Schema::table('a3_programs', function (Blueprint $table) {
            // Hapus constraint UNIQUE
            $table->dropUnique(['kode_program']);

            // Tambahkan INDEX biasa
            $table->index('kode_program');
        });
        Schema::table('a4_kegiatans', function (Blueprint $table) {
            // Hapus constraint UNIQUE
            $table->dropUnique(['kode_kegiatan']);

            // Tambahkan INDEX biasa
            $table->index('kode_kegiatan');
        });
        Schema::table('a5_subkegiatans', function (Blueprint $table) {
            // Hapus constraint UNIQUE
            $table->dropUnique(['kode_subkegiatan']);

            // Tambahkan INDEX biasa
            $table->index('kode_subkegiatan');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        //
    }
};
