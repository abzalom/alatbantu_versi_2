<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('rap_otsuses', function (Blueprint $table) {
            $table->string('kode_unik_sikd')->after('kode_unik_opd_tag_otsus')->nullable()->index();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('rap_otsuses', function (Blueprint $table) {
            //
        });
    }
};
